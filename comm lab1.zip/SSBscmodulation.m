%% -----------------------------------SSB-SC Modulation-----------------------------------------------
%Here we convert our baseband signal to passband signal by multiplting with
%carrier signal
function [x_mod] = SSBscmodulation(x_t,x_delta_t,c_t,fc,t)
x_mod = c_t.*x_t - x_delta_t.*sin(2*pi*fc*t); %SSB-Sc modulation
end

%x_t is message signal
%x_delta_t is hilbert transform of message signal
%c_t is carrier signal
%fc is frequency of carrier signal
%t is total time of signal
%x_mod is modulated signal using SSB-SC modulation