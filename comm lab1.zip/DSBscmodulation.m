%% -----------------------------DSB-SC Modulation-------------------------------------------
%Here we convert our baseband signal to passband signal by multiplting with
%carrier signal
function [x_mod] = DSBscmodulation(x_t,c_t,Am)
%x_t = x_t./Am;
x_mod = x_t.*c_t; % DSBsc modulation
end

%x_t is message signal
%x_c is carrier signal
%x_mod is modulated signal using DSB-SC modulation