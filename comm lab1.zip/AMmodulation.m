%% ------------------------------Conventional-AM Modulation-------------------------------
%Here we convert our baseband signal to passband signal by multiplting with
%carrier signal
function [x_mod] = AMmodulation(amod,x_t,c_t,M0,Am)
m = x_t/Am; 
x_mod = c_t.*(1+(amod/M0)*m); %AM modulation
end

%x_t is message signal
%c_t is carrier signal
%Am is amplitude of message signal
%amod is modulation index
%M0 is modulus of minimum value of message signal
%x_mod is modulated signal using Conventional AM modulation