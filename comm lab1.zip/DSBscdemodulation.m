%% -------------------------------------------DSB-SC demodulation------------------------------------
%Here we multiply modulated signal with carrier signal and remove high
%frequencies using butterworth low pass filter
function [x_demod] = DSBscdemodulation(x_mod,c_t,Ac,fc,fs)
x_dem = x_mod.*c_t; % Square law demodulation
[b,a] = butter(10,fc/(fs/2),'low');% using Butterworth filter to remove high frequency components
x_demod = filter(b,a,x_dem); %filtering to remove high frequency components

x_demod = x_demod./(2*Ac);%amplitude scaling and shifting as we get positive frequencies after demodulation due Ac*Ac

end

%x_mod is modulated message signal
%c_t is carrier signal
%Ac is amplitude of carrier signal
%fc is frequency of carrier signal
%fs is sampling frequency
%x_demod is demodulated signal using coherent demodulation