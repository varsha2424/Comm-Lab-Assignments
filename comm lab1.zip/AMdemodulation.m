%% ----------------------------ConventionalAM Demodulation------------------------------------------
%Here we multiply modulated signal with carrier signal and remove high
%frequencies using butterworth low pass filter
function [x_demod] = AMdemodulation(x_mod,c_t,Ac,fc,fs)
c_t = c_t./Ac;%carrier signal
x_dem = c_t.*x_mod; % Square law demodulation
[b,a] = butter(6,fc/(fs/2),'low'); % using Butterworth filter to remove high frequency components
x_demod = filter(b,a,x_dem);%filtering
x_demod = x_demod.*2 - Ac; %amplitude scaling and shifting as we get positive frequencies after demodulation due Ac*Ac
%x_demod = lowpass(x_dem,fm+0.5*fm,fs);
end

%x_mod is modulated message signal
%c_t is carrier signal
%Ac is amplitude of carrier signal
%fc is frequency of carrier signal
%fs is sampling frequency
%x_demod is demodulated signal using coherent demodulation