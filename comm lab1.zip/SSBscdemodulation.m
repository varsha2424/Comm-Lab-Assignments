%% -------------------------------------SSB-SC Demodulation--------------------------------------------------
%Here we multiply modulated signal with carrier signal and remove high
%frequencies using butterworth low pass filter
function [x_demod] = SSBscdemodulation(x_mod,c_t,fc,fs)
x_dem = c_t.*x_mod; % Square law demodulation(coherent demodulation)
[b,a] = butter(6,fc/(fs/2),'low');% using Butterworth filter to remove high frequency components
x_demod = filter(b,a,x_dem); %filtering
x_demod = x_demod*2;%amplitude scaling and shifting as we get positive frequencies after demodulation due Ac*Ac
%x_demod = lowpass(x_dem,fm+0.5*fm,fs);
end

%x_mod is modulated message signal
%c_t is carrier signal
%Ac is amplitude of carrier signal
%fc is frequency of carrier signal
%fs is sampling frequency
%x_demod is demodulated signal using coherent demodulation