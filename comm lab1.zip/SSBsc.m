clc;
close all;
clear all;

%% ---------------------------------message signal generation------------------------------------------------------
Am = 5; %Amplitude of message signal
fm=200; % Frequency of message signal
Tm=1/fm; % Time period of message signal
Ts = 0.0001; %sampling period
fs = 1/Ts;%sampling frequency
t = 0:Ts:6*Tm; %Total time for simulation
x_t = Am*cos(2*pi*fm*t); % generating message signal

%% ---------------------------------plotting message signal--------------------------------------------------------
figure;
subplot(3,2,1);
plot(t,x_t);
axis([ 0 6*Tm -6 6]);
grid;
title("Message signal m(t)");
xlabel("Time(sec)");
ylabel("Amplitude(volt)");

%% -------------------------------hilbert transform of message signal------------------------------------------------
x_delta_t = imag(hilbert(x_t));%hilbert transform of message signal we considered imaginary part because message signal is real part


%% -------------------------------carrier signal generation-----------------------------------------------------------
Ac=1;% Amplitude of carrier signal 
fc=fm*10;% Frequency of carrier signal
Tc=1/fc;% Time period of carrier signal
c_t =Ac*cos(2*pi*fc*t);% generating carrier signal

%% -------------------------------plotting carrier signal-------------------------------------------------------------
subplot(3,2,2);
plot(t,c_t);
axis([ 0 6*Tm -1.5 1.5]);
grid;
title("carrier signal c(t)");
xlabel("Time(sec)");
ylabel("Amplitude(volt)");

%% ------------------------------SSB-SC Modulation--------------------------------------------------------------------
x_mod = SSBscmodulation(x_t,x_delta_t,c_t,fc,t);

%% ------------------------------plotting modulated message signal----------------------------------------------------
subplot(3,2,3);
plot(t,x_mod);
grid;
title("Modulated message signal");
xlabel("Time(sec)");
ylabel("Amplitude(volt)");

%% ----------------------------------Coherent demodulation-------------------------------------------------------------
x_demod = SSBscdemodulation(x_mod,c_t,fc,fs);

%% ---------------------------------plotting demodulated signal---------------------------------------------------------
subplot(3,2,4);
plot(t,x_demod);
grid;
title("Demodulated signal");
xlabel("Time(sec)");
ylabel("Amplitude(volt)");

%% --------------------frequency domain(Magnitude response) representation of message signal------------------------------
l = length(x_t); %length of message signal
N = 512; % Took N such N>L(length of signal) to avoid aliasing
f = fs*[-N/2:N/2-1]/N; %frequency
x_f = fftshift(fft(x_t,N));% fft of msg signal
figure(2);
subplot(2,2,1)
plot(f,abs(x_f));
grid;
title(" message signal(Frequency response)");
xlabel("f(Hz)");
ylabel("|M(f)|");

%% ------------------frequency domain(Magnitude response) representation of carrier signal-----------------------------------
c_f = fftshift(fft(c_t,N)); % fft of carrier signal
subplot(2,2,2)
plot(f,abs(c_f));
grid;
title(" carrier signal(Frequency response)");
xlabel("f(Hz)");
ylabel("|C(f)|");

%% -------------------frequency domain(Magnitude response) representation of Modulated message signal--------------------------
X_mod = fftshift(fft(x_mod,N)); %fft of modulated message signal;
subplot(2,2,3)
plot(f,abs(X_mod));
grid;
title(" Modulated signal(Frequency response)");
xlabel("f(Hz)");
ylabel("|Xmod(f)|");


%% -------------------frequency domain(Magnitude response) representation of Demodulated message signal--------------------------
X_demod = fftshift(fft(x_demod,N)); %fft of Demodulated message signal;
subplot(2,2,4)
plot(f,abs(X_demod));
grid;
title(" Demodulated signal(Frequency response)");
xlabel("f(Hz)");
ylabel("|Xdemod(f)|");





