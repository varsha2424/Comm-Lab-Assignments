%% ----------------------------clearing workspace and command prompt------------------------------
clc;
close all;
clear all;

%% ----------------------------- message signal generation-----------------------------------------
Am = 5; %Amplitude of message signal
fm=200; % Frequency of message signal
Tm=1/fm; % Time period of message signal
Ts = 0.0001; %Sampling period
fs = 1/Ts; %sampling frequency
t = 0:Ts:6*Tm; %Total time for simulation
x_t = Am*cos(2*pi*fm*t); % generating message signal

%% -----------------------------------plotting message signal---------------------------------------
figure;
subplot(3,2,1);
plot(t,x_t);
axis([ 0 6*Tm -6 6]);
grid;
title("Message signal m(t)");
xlabel("Time(sec)");
ylabel("Amplitude(volt)");

%% ------------------------------------modulation index----------------------------------------------
amod = 1; % for 100% modulation

%% -------------------------------finding min value of signal M0--------------------------------------
[val,idx] = min(x_t/Am) ;   % getting  minimum value of message signal and it's index 
M0 = abs(val); %Taking absolute minimum value

%% ---------------------------------carrier signal generation-----------------------------------------
Ac=Am*M0/amod;% Amplitude of carrier signal (since modulation Index (amod)=Am*M0/Ac ]
fc=fm*10;% Frequency of carrier signal
Tc=1/fc;% Time period of carrier signal
c_t =Ac*cos(2*pi*fc*t);% generating carrier signal

%% --------------------------------plotting carrier signal---------------------------------------------
subplot(3,2,2);
plot(t,c_t);
axis([ 0 6*Tm -6 6]);
grid;
title("carrier signal c(t)");
xlabel("Time(sec)");
ylabel("Amplitude(volt)");

%% ---------------------------------------------AM modulation-------------------------------------------
x_mod = AMmodulation(amod,x_t,c_t,M0,Am); %Conventional AM modulation

%% ---------------------------------plotting modulated message signal-----------------------------------
subplot(3,2,3);
plot(t,x_mod);
grid;
title("Modulated message signal");
xlabel("Time(sec)");
ylabel("Amplitude(volt)");

%% ------------------------------------Demodulationg signal--------------------------------------------
x_demod = AMdemodulation(x_mod,c_t,Ac,fc,fs); %coherent demodulation

%% -------------------------------------plotting demodulated signal-------------------------------------
subplot(3,2,4);
%figure(3);
plot(t,x_demod);
grid;
title("Demodulated signal");
xlabel("Time(sec)");
ylabel("Amplitude(volt)");

%% --------------------frequency domain(Magnitude response) representation of message signal-------------
l = length(x_t); %length of message signal
N = 512; % Took N such N>L(length of signal) to avoid aliasing
f = fs*[-N/2:N/2-1]/N; %frequency
x_f = fftshift(fft(x_t,N));% fft of msg signal
figure(2);
subplot(2,2,1)
plot(f,abs(x_f));
grid;
title(" message signal(Frequency response)");
xlabel("f(Hz)");
ylabel("|M(f)|");

%% ----------------------frequency domain(Magnitude response) representation of carrier signal-----------------
c_f = fftshift(fft(c_t,N)); % fft of carrier signal
subplot(2,2,2)
plot(f,abs(c_f));
grid;
title(" carrier signal(Frequency response)");
xlabel("f(Hz)");
ylabel("|C(f)|");

%% -----------------------frequency domain(Magnitude response) representation of Modulated message signal---------
X_mod = fftshift(fft(x_mod,N)); %fft of modulated message signal;
subplot(2,2,3)
plot(f,abs(X_mod));
grid;
title(" Modulated signal(Frequency response)");
xlabel("f(Hz)");
ylabel("|Xmod(f)|");


%% --------------------frequency domain(Magnitude response) representation of Demodulated message signal---------
X_demod = fftshift(fft(x_demod,N)); %fft of Demodulated message signal;
subplot(2,2,4)
plot(f,abs(X_demod));
grid;
title(" Demodulated signal(Frequency response)");
xlabel("f(Hz)");
ylabel("|Xdemod(f)|");

