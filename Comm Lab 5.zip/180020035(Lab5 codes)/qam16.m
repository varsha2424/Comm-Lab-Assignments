%% -------------------------------------clearing workspace and command prompt------------------------------------------------------
clear all;
close all;
clc;

%% -------------------------------------Simulation of 16QAM in AWGN channel---------------------------------------------------------
constellations = (1/sqrt(10))*[-3-3i,-3-1i,-3+1i,-3+3i,-1-3i,-1-1i,-1+1i,-1+3i,1-3i,1-1i,1+1i,1+3i,3-3i,3-1i,3+1i,3+3i]; %normalised QPSK mappings without gray labeling
                                                      %(mapping 0000 to -3-3i,0001 to -3-1i, 0010 to -3+1i, 0011 to -3+3i,
                                                      %0100 to -1-3i,0101 to -1-1i,0110 to -1+1i,0111 to -1+3i,
                                                      %1000 to 1-3i,1001 to 1-1i,1010 to 1+1i,1011 to 1+3i,
                                                      %1100 to 3-3i,1101 to 3-1i,1110 to 3+1i,1111 to 3+3i)
gray_constellations = (1/sqrt(10))*[1+1i,1-1i,-1+1i,-1-1i,1+3i,1-3i,-1+3i,-1-3i,3+3i,3-1i,-3+1i,-3-1i,3+3i,3-3i,-3+3i,-3-3i];%normalised QPSK mappings with gray labeling
                                                      %(mapping 0000 to 1+1i,0001 to 1-1i,0010 to -1+1i,0011 to -1-1i,
                                                      %0100 to 1+3i,0101 to 1-3i,0110 to -1+3i,0111 to -1-3i,
                                                      %1000 to 3+3i,1001 to 3-1i,1010 to -3+1i,1011 to -3-1i,
                                                      %1100 to 3+3i,1101 to 3-3i,1110 to -3+3i,1111 to -3-3i)
snr_db = 0:0.5:15; %SNR values in DB
signal_len = 1000; %length of signal
snrs_len = length(snr_db); %length of SNR values
perr_estimate_non_gray = zeros(1,snrs_len); %bit error rates for taken SNR Values for without gray labeling
perr_estimate_gray = zeros(1,snrs_len); %bit error rates for taken SNR Values for with gray labeling
k = 4;%no of bits per symbol

%-----------------------------------Binary Signal Genration-----------------------------------------

signal_bits = randi([0 1],1,signal_len*k);%generating random numbers(0,1,2,3)with equal probability as to use ML detection
signal = reshape(signal_bits,k,signal_len).';%Input signal

%---------------------------Modulating signal with and without gray labeling--------------------------

modulated_signal = []; 
gray_modulated_signal = [];
for iter=1:length(signal)
    if signal(iter,:) == [0 0 0 0]
        modulated_signal = [modulated_signal;constellations(1)];%mapping 0000 to -3-3i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(1)];%mapping 0000 to 1+1i
    elseif signal(iter,:) == [0 0 0 1]
        modulated_signal = [modulated_signal;constellations(2)];%mapping 0001 to -3-1i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(2)];%mapping 0001 to 1-1i
    elseif signal(iter,:) == [0 0 1 0]
        modulated_signal = [modulated_signal;constellations(3)];%mapping 0010 to -3+1i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(3)];%mapping 0010 to -1+1i
    elseif signal(iter,:) == [0 0 1 1]
        modulated_signal = [modulated_signal;constellations(4)]; %mapping 0011 to -3+3i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(4)]; %mapping 0011 to -1-1i
    elseif signal(iter,:) == [0 1 0 0]
        modulated_signal = [modulated_signal;constellations(5)];%mapping 0100 to -1-3i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(5)];%mapping 0100 to 1+3i
    elseif signal(iter,:) == [0 1 0 1]
        modulated_signal = [modulated_signal;constellations(6)];%mapping 0101 to -1-1i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(6)];%mapping 0101 to 1-3i
    elseif signal(iter,:) == [0 1 1 0]
        modulated_signal = [modulated_signal;constellations(7)];%mapping 0110 to -1+1i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(7)];%mapping 0110 to -1+3i
    elseif signal(iter,:) == [0 1 1 1]
        modulated_signal = [modulated_signal;constellations(8)];%mapping 0111 to -1+3i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(8)];%mapping 0111 to -1-3i
    elseif signal(iter,:) == [1 0 0 0]
        modulated_signal = [modulated_signal;constellations(9)];%mapping 1000 to 1-3i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(9)];%mapping 1000 to 3+3i
    elseif signal(iter,:) == [1 0 0 1]
        modulated_signal = [modulated_signal;constellations(10)];%mapping 1001 to 1-1i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(10)];%mapping 1001 to 3-1i
    elseif signal(iter,:) == [1 0 1 0]
        modulated_signal = [modulated_signal;constellations(11)];%mapping 1010 to 1+1i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(11)];%mapping 1010 to -3+1i
    elseif signal(iter,:) == [1 0 1 1]
        modulated_signal = [modulated_signal;constellations(12)];%mapping 1011 to 1+3i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(12)];%mapping 1011 to -3-1i
    elseif signal(iter,:) == [1 1 0 0]
        modulated_signal = [modulated_signal;constellations(13)];%mapping 1100 to 3-3i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(13)];%mapping 1100 to 3+3i
    elseif signal(iter,:) == [1 1 0 1]
        modulated_signal = [modulated_signal;constellations(14)];%mapping 1101 to 3-1i 
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(14)];%mapping 1101 to 3-3i   
    elseif signal(iter,:) == [1 1 1 0]
        modulated_signal = [modulated_signal;constellations(15)];%mapping 1110 to 3+1i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(15)];%mapping 1110 to -3+3i
    elseif signal(iter,:) == [1 1 1 1]
        modulated_signal = [modulated_signal;constellations(16)];%mapping 1111 to 3+3i
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(16)];%mapping 1111 to -3-3i
    end
end


%-----------------------------------------Simulation---------------------------------------
for snr=1:snrs_len %loop for snrs
    
    snrdb_now = snr_db(snr); %current SNR value in DB
    snr_now=10^(snrdb_now/10);%current SNR value in Linear Scale
    %sigma = sqrt(1/log2(M)*snb) here M = 16
    sigma=sqrt(1/(k*snr_now)); %sigma for corresponding SNR 
    error=zeros(1,signal_len); %error vector for current SNR for without gray labeling modulation
    gray_error=zeros(1,signal_len); %error vector for current SNR for with gray labeling modulation
    
    for i = 1:signal_len
        
         %In this loop we are adding AWGN noise to modulated signal for about 1000
         %times( length of signal) and we are considering average error rate(error probability) as
         %bit error rate for current snr
         
         %Adding normalised complex guassian noise to with gray modulated signal and
         %without gray modulated signal
         corrupted_signal = modulated_signal + [(sigma/sqrt(2))*(randn(1,length(modulated_signal))+1i*randn(1,length(modulated_signal)))]';
         gray_corrupted_signal = gray_modulated_signal + [(sigma/sqrt(2))*(randn(1,length(gray_modulated_signal))+1i*randn(1,length(gray_modulated_signal)))]';
         
         %Demodulating gray labeled corrupted signal and without gray
         %labeled signal
         %logic for demodulation - 
         %We are finding distance from each symbol and mapping to symbol
         %which has minimum distance
         demodulated_signal = [];%demodulated signal for without gray labeling modulation
         gray_demodulated_signal = [];%demodulated signal for with gray labeling modulation
         
         for cs = 1:length(corrupted_signal)
             dist = [];%distance for without gray labeled corrupted signal
             gray_dist = [];%distance for withgray labelled corrupted signal
             
             for j = 1:length(constellations)
                 %In this loop we find distance of corrupted signal(gray labeled and without gray labeled)
                 %with respective symbols
                 dist(j) = norm(corrupted_signal(cs)-constellations(j));%distance of corrupted signal from without gray labelled constellations
                 gray_dist(j) = norm(gray_corrupted_signal(cs)-gray_constellations(j));%distance of corrupted signal from with gray labelled constellations
             end
             
             [mini,index] = min(dist);%finding min index for without gray labeled corrupted signal
             [gray_mini,gray_index] = min(gray_dist);%finding min index for with gray labeled corrupted signal
             demodulated_signal = [demodulated_signal;constellations(index)];%appending min distance symbol for demodulated signal
             gray_demodulated_signal = [gray_demodulated_signal;gray_constellations(gray_index)];%appending min distance symbol for demodulated signal
         end
         
         %finding bit error for demodulated signal (gray labeled and without gray labeled)
         error(i) =ber(demodulated_signal,modulated_signal);
         gray_error(i) =ber(gray_demodulated_signal,gray_modulated_signal);
    
    end
    perr_estimate_non_gray(snr) = mean(error)/k;%appending average error as bit error rate for current SNR(for without gray labeled)
                                               %divided by k as total no of bits are k*signal_len
    perr_estimate_gray(snr) = mean(gray_error)/k;%appending average error as bit error rate for current SNR(for gray labeled)
                                                %divided by k as total no of bits are k*signal_len
end
%% -----------------------------Theoretical values using Q-function(Intelligent Union Bound)----------------------------------------
theory_snr=0:.5:15; %theoretical SNR values in DB
theory_snr_lin=10.^(theory_snr./10);%theoretical SNR values in Linear scale
ber = (1/k)*3/2*erfc(sqrt(k*(1/10)*theory_snr_lin));%theoretical bit error rate

%% -----------------------------Comparing theoretical vs simulated Bit error rates for without gray labeling------------------------- 
figure;
semilogy(theory_snr,ber,'b-','linewidth',2) %semilog plot for theoretical bit error rates
hold on
semilogy(snr_db,perr_estimate_non_gray,'r-o') %semilog plot for simulated bit error rates
hold off
title('16QAM over AWGN Simulation with gray labeling');
xlabel('SNR in dB');
ylabel('BER');
legend('BER(Theoretical)','BER(Simulated)')
%ber = 1.8*ber;
grid;


%% -----------------------------Comparing theoretical vs simulated Bit error rates for gray labeling---------------------------------- 
figure;
semilogy(theory_snr,ber,'b-','linewidth',2) %semilog plot for theoretical bit error rates
hold on
semilogy(snr_db,perr_estimate_gray,'r-o') %semilog plot for simulated bit error rates
hold off
title('16QAM over AWGN Simulation without gray labeling');
xlabel('SNR in dB');
ylabel('BER');
legend('BER(Theoretical)','BER(Simulated)')
grid;

