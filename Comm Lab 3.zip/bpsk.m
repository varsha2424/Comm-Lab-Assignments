%% -------------------------------------clearing workspace and command prompt------------------------------------------------------
clear all;
close all;
clc;

%% -------------------------------------Simulation of BPSK in AWGN channel---------------------------------------------------------
constellations = [-1,1]; %BPSK mappings(mapping 0 to -1 and 1 to +1)
snr_db = -20:0.5:15; %SNR values in DB
signal_len = 10000; %length of signal
snrs_len = length(snr_db); %length of SNR values
perr_estimate = zeros(1,snrs_len); %bit error rates for taken SNR Values

%----------------------------Binary Signal Genration------------------
signal_bits = randi([0 1], 1,signal_len);%generating random bits(0 or 1)with equal probability

%---------------------------Modulating signal--------------------------
modulated_signal = 2.*signal_bits -1; %we are mapping our binary signal to bpsk constellation i.e 0 to -1 and 1 to +1

%-----------------------------Simulation-------------------------------
for k=1:snrs_len %loop for snrs
    
    snrdb_now = snr_db(k); %current SNR value in DB
    snr_now=10^(snrdb_now/10);%current SNR value in Linear Scale
    sigma=sqrt(1/(2*snr_now)); %sigma for corresponding SNR (wriiten in handwritten)
    error=zeros(1,signal_len); %error vector for current SNR
    
    for i = 1:signal_len 
         %In this loop we are adding AWGN noise to modulated signal for about 10000
         %times( length of signal) and we are considering average error rate(error probability) as
         %bit error rate for current snr
         
         %Adding complex guassian noise to modulated signal
         corrupted_signal = modulated_signal + sigma*randn(1,signal_len)+1i*sigma*randn(1,signal_len);
         
         %Demodulating corrupted signal 
         %logic for demodulation - 
         %As our signal is real we are considering real part of corrupted signal
         %As prior probabilties are equal (We generated equi-probable
         %signal bits) we demodulate signal using ML rule 
         %Threshold = (-1 + (+1))/2 == 0
         demodulated_signal = real(corrupted_signal)>0;
         
         %finding bit error for demodulated signal
         error(i) = ber(demodulated_signal,signal_bits);
    
    end
    perr_estimate(k) = mean(error);%appending average error as bit error rate for current SNR
end

%% -----------------------------Theoretical values using Q-function(Intelligent Union Bound)-------------------------------------
theory_snr=-20:0.5:15; %theoretical SNR values in DB
theory_snr_lin=10.^(theory_snr./10);%theoretical SNR values in Linear scale
ber=1/2.*erfc(sqrt((theory_snr_lin)));%bit error rates using complementary error function

%% -----------------------------Comparing theoretical vs simulated Bit error rates------------------------------------------------ 
plot(theory_snr,ber,'b-','linewidth',2) %semilog plot for theoretical bit error rates
hold on
plot(snr_db,perr_estimate,'r-o') %semilog plot for simulated bit error rates
hold off
title('BPSK over AWGN Simulation');
xlabel('SNR in dB');ylabel('BER');
legend('BER(Simulated)','BER(Theoritical)')
grid;
