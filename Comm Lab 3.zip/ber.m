%% ----------------------------------------------BER function---------------------------------------------------------
%This function computes bit error rate for given demodulated and message signal
function b = ber(demodulated_signal,signal_bits)
cmp = demodulated_signal==signal_bits;% comparing demodulated signal and message signal
cmp = sum(cmp);%sum of correctly predicted bits
b = length(demodulated_signal)- cmp;%sum of erroneous predictions of bits
b = b/length(demodulated_signal);%bit error rate 
end

% b - bit error rate
%demodulated_signal - demodulated message signal
%signal_bits - Binary message signal