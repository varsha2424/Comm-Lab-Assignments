%% -------------------------------------clearing workspace and command prompt------------------------------------------------------
clear all;
close all;
clc;
%% bpsk vs dbpsk when there is phase shifting
%% ------------------------------------Initialisations-----------------------------------------
reference_bit = randi([0 1], 1,1); %reference bit for differential encoding
snr_db = -20:0.5:10; %SNR values in DB
signal_len = 1000 ;%length of signal
snrs_len = length(snr_db); %length of SNR values
perr_estimate_bpsk = zeros(1,snrs_len); %bit error rates for taken SNR Values for bpsk
perr_estimate_dbpsk = zeros(1,snrs_len);%bit error rates for taken SNR Values for dbpsk

%% ---------------------------------Binary Signal Genration--------------------------------------
signal_bits = randi([0 1], 1,signal_len);%generating random bits(0 or 1)with equal probability

%% -------------------------Encoding signal using differential encoding--------------------------
%Logic for encoding- Here encoded bit is generated based on the previous
%bit i.e if current signal bit and previous encoded bit are equal then we
%set current encoded bit to 1 ,else 0

encoded_signal = [reference_bit,zeros(1,signal_len)]; %Encoded signal where first bit is taken as reference bit
for i = 2:length(encoded_signal) %considering from 2 as 1 is fixed i.e refernce bit
    encoded_signal(i)= encoded_signal(i-1)==signal_bits(i-1);%comparing current  signal bit and previous encoded bit and shifting
end

%% -------------------------------------Modulating encoded signal---------------------------------
modulated_signal_dbpsk = (2.*encoded_signal -1).*(exp(1i*2*pi/3)); %we are mapping our binary encoded signal to bpsk constellation i.e 0 to -1 and 1 to +1
modulated_signal_bpsk = (2.*signal_bits -1).*(exp(1i*2*pi/3)); %we are mapping our binary encoded signal to bpsk constellation i.e 0 to -1 and 1 to +1

%% ---------------------------------------------Simulation----------------------------------------
for snr=1:snrs_len %loop for snrs
    
    snrdb_now = snr_db(snr); %current SNR value in DB
    snr_now=10^(snrdb_now/10);%current SNR value in Linear Scale
    sigma=sqrt(1/(2*snr_now)); %sigma for corresponding SNR (wriiten in handwritten)
    error=zeros(1,signal_len); %error vector for current SNR for dbpsk
    error_bpsk=zeros(1,signal_len); %error vector for current SNR for bpsk
    
    for i = 1:signal_len
         %In this loop we are adding AWGN noise to modulated signal for about 10000
         %times( length of signal) and we are considering average error rate(error probability) as
         %bit error rate for current snr
         
         %----------------------Adding complex guassian noise to modulated signal-------------------
         corrupted_signal_dbpsk = modulated_signal_dbpsk + sigma*randn(1,signal_len+1)+1i*sigma*randn(1,signal_len+1);
         corrupted_signal_bpsk = modulated_signal_bpsk + sigma*randn(1,signal_len)+1i*sigma*randn(1,signal_len);
         
         %--------------------------------Demodulating corrupted signal----------------------------- 
         %logic for demodulation - 
         %As our signal is real we are considering real part of corrupted signal
         %As prior probabilties are equal (We generated equi-probable
         %signal bits) we demodulate signal using ML rule 
         %Threshold = (-1 + (+1))/2 == 0
         demodulated_signal_bpsk = real(corrupted_signal_bpsk)>0; 
         demodulated_signal_dbpsk = real(corrupted_signal_dbpsk)>0; 
         
         %----------------------------------Decoding Signal-----------------------------------------
         %Logic for decoding - Here we are comparing adjacent demodulated bits and
         %if they are equal we are setting decoded bit to 1 else 0 
         decoded_signal = [zeros(1,signal_len)]; %decoded signal
         for j = 2:length(demodulated_signal_dbpsk)%considering from 2 as 1 is fixed i.e refernce bit
           decoded_signal(j-1)= demodulated_signal_dbpsk(j)==demodulated_signal_dbpsk(j-1);%comparing adjacent demodulated bits
         end
         
         %finding bit error for decoded signal
         error(i) = ber(decoded_signal,signal_bits);
         error_bpsk(i) = ber(demodulated_signal_bpsk,signal_bits);
    
    end
    perr_estimate_dbpsk(snr) = mean(error);%appending average error as bit error rate for current SNR for dbpsk
    perr_estimate_bpsk(snr) = mean(error_bpsk);%appending average error as bit error rate for current SNR fpr bpsk
end

%% Comparing dbpsk and bpsk ber
semilogy(snr_db,perr_estimate_dbpsk,'b') %semilog plot for theoretical bit error rates
hold on
semilogy(snr_db,perr_estimate_bpsk,'r') %semilog plot for simulated bit error rates
hold off
title('DBPSK vs BPSK');
xlabel('SNR in dB');ylabel('BER');
legend('BER(Dbpsk)','BER(Bpsk)')
grid;