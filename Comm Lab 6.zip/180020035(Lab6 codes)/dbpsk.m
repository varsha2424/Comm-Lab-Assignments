%% -------------------------------------clearing workspace and command prompt------------------------------------------------------
clear all;
close all;
clc;

%% -------------------------------------Simulation of BPSK in AWGN channel---------------------------------------------------------

%% ------------------------------------Initialisations-----------------------------------------
reference_bit = randi([0 1], 1,1); %reference bit for differential encoding
snr_db = -20:0.5:10; %SNR values in DB
signal_len = 1000 ;%length of signal
snrs_len = length(snr_db); %length of SNR values
perr_estimate = zeros(1,snrs_len); %bit error rates for taken SNR Values

%% ---------------------------------Binary Signal Genration--------------------------------------
signal_bits = randi([0 1], 1,signal_len);%generating random bits(0 or 1)with equal probability

%% -------------------------Encoding signal using differential encoding--------------------------
%Logic for encoding- Here encoded bit is generated based on the previous
%bit i.e if current signal bit and previous encoded bit are equal then we
%set current encoded bit to 1 ,else 0

encoded_signal = [reference_bit,zeros(1,signal_len)]; %Encoded signal where first bit is taken as reference bit
for i = 2:length(encoded_signal) %considering from 2 as 1 is fixed i.e refernce bit
    encoded_signal(i)= encoded_signal(i-1)==signal_bits(i-1);%comparing current  signal bit and previous encoded bit and shifting
end

%% -------------------------------------Modulating encoded signal---------------------------------
modulated_signal = 2.*encoded_signal -1; %we are mapping our binary encoded signal to bpsk constellation i.e 0 to -1 and 1 to +1

%% ---------------------------------------------Simulation----------------------------------------
for snr=1:snrs_len %loop for snrs
    
    snrdb_now = snr_db(snr); %current SNR value in DB
    snr_now=10^(snrdb_now/10);%current SNR value in Linear Scale
    sigma=sqrt(1/(2*snr_now)); %sigma for corresponding SNR (wriiten in handwritten)
    error=zeros(1,signal_len); %error vector for current SNR
    
    for i = 1:signal_len
         %In this loop we are adding AWGN noise to modulated signal for about 10000
         %times( length of signal) and we are considering average error rate(error probability) as
         %bit error rate for current snr
         
         %----------------------Adding complex guassian noise to modulated signal-------------------
         corrupted_signal = modulated_signal + sigma*randn(1,signal_len+1)+1i*sigma*randn(1,signal_len+1);
         
         %--------------------------------Demodulating corrupted signal----------------------------- 
         %logic for demodulation - 
         %As our signal is real we are considering real part of corrupted signal
         %As prior probabilties are equal (We generated equi-probable
         %signal bits) we demodulate signal using ML rule 
         %Threshold = (-1 + (+1))/2 == 0
         demodulated_signal = real(corrupted_signal)>0; 
         
         %----------------------------------Decoding Signal-----------------------------------------
         %Logic for decoding - Here we are comparing adjacent demodulated bits and
         %if they are equal we are setting decoded bit to 1 else 0 
         decoded_signal = [zeros(1,signal_len)]; %decoded signal
         for j = 2:length(demodulated_signal)%considering from 2 as 1 is fixed i.e refernce bit
           decoded_signal(j-1)= demodulated_signal(j)==demodulated_signal(j-1);%comparing adjacent demodulated bits
         end
         
         %finding bit error for decoded signal
         error(i) = ber(decoded_signal,signal_bits);
    
    end
    perr_estimate(snr) = mean(error);%appending average error as bit error rate for current SNR
end

%% -----------------------------Theoretical values(Intelligent Union Bound)-------------------------------------
theory_snr=-20:0.5:10; %theoretical SNR values in DB
theory_snr_lin=10.^(theory_snr./10);%theoretical SNR values in Linear scale
ber=1/2*exp(-1*theory_snr_lin);%bit error rates 

%% -----------------------------Comparing theoretical vs simulated Bit error rates------------------------------------------------ 
semilogy(theory_snr,ber,'b-','linewidth',2) %semilog plot for theoretical bit error rates
hold on
semilogy(snr_db,perr_estimate,'r-o') %semilog plot for simulated bit error rates
hold off
title('DBPSK over AWGN Simulation');
xlabel('SNR in dB');ylabel('BER');
legend('BER(Theoretical)','BER(Simulated)')
grid;

