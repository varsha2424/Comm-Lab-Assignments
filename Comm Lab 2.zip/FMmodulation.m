%% -----------------------------------FM Modulation-----------------------------------------------
%Here we add our integrated message signal to phase of carrier signal
function [x_mod] = FMmodulation(exp,t,fc,kf,theta_init,Ac)
int_x = zeros(1,length(t));%initialising
for i = 1:length(int_x)
    int_x(i) = integral(exp,0,t(i)); %integration of message signal
end
x_mod= Ac*cos(2*fc*pi*t + 2*pi*kf*int_x + theta_init); %FM modulation
end

%exp is funtion of message signal
%t is total time for simulation
%fc is frequency of carrier signal
%kf is constant in FM
%theta_init is initial phase
%Ac is amplitude of carrier signal