%% -------------------------------------clearing workspace and command prompt------------------------------------------------------
clear all;
close all;
clc;

%% --------------------------------------------message signal generation-----------------------------------------------------------
Am = 5; %Amplitude of message signal
fm=100; % Frequency of message signal
Tm=1/fm; % Time period of message signal
Ts = 0.0001; %Sampling period
fs = 1/Ts; %sampling frequency
t = 0:Ts:6*Tm; %Total time for simulation
x_t = Am*cos(2*pi*fm*t); % generating message signal

%% ------------------------------------------plotting message signal--------------------------------------------------------------
figure;
subplot(3,1,1);
plot(t,x_t);
grid;
title("Message signal m(t)");
xlabel("Time(sec)");
ylabel("Amplitude(volt)");

%% ---------------------------------------carrier signal generation---------------------------------------------------------------
Ac = 5;%Amplitude of carrier signal
fc=fm*5;% Frequency of carrier signal
Tc=1/fc;% Time period of carrier signal
c_t =Ac*cos(2*pi*fc*t);% generating carrier signal

%% ---------------------------------------plotting carrier signal-----------------------------------------------------------------
subplot(3,1,2);
plot(t,c_t);
grid;
title("carrier signal c(t)");
xlabel("Time(sec)");
ylabel("Amplitude(volt)");

%% -------------------------------------finding max value of signal M0------------------------------------------------------------
[val,idx] = max(x_t) ;   % getting  maximum value of message signal and it's index 
M0 = val; % maximum value

%% -------------------------------------------------------FM modulation-----------------------------------------------------------
freqdev = 160;%frequency deviation
kf = freqdev/M0;%constant of FM modulation (since frequency deviation = kf *max(msg signal))
theta_init = 0; %considering zero initial conditions i.e initial phase = 0
%syms t1;
exp =  @(t) Am*cos(2*pi*fm*t); %function for integration function matlab
x_mod = FMmodulation(exp,t,fc,kf,theta_init,Ac); %FM modulation

%% ---------------------------------------------plotting modulated message signal------------------------------------------------
subplot(3,1,3);
plot(t,x_mod);
grid;
title("Modulated message signal");
xlabel("Time(sec)");
ylabel("Amplitude(volt)");

%% -----------------------------------------------DEMODULATION Using Envelope detection------------------------------------------
x_demod = FMdemodulation(x_mod); %Demodulation using Envelope technique

%% -----------------------------------------------plotting demodulated signal------------------------------------------------------

figure;
plot(t,x_demod);
grid;
title("Demodulated signal");
xlabel("Time(sec)");
ylabel("Amplitude(volt)");
ylim([-5 5])

%% ------------------------------------frequency domain(Magnitude response) representation of message signal-----------------------
l = length(x_t); %length of message signal
N = 512; % Took N such N>L(length of signal) to avoid aliasing
f = fs*[-N/2:N/2-1]/N; %frequency
x_f = fftshift(fft(x_t,N));% fft of msg signal
figure;
subplot(4,1,1)
plot(f,abs(x_f));
grid;
title(" message signal(Frequency response)");
xlabel("f(Hz)");
ylabel("|M(f)|");

%% --------------------------------frequency domain(Magnitude response) representation of carrier signal----------------------------
c_f = fftshift(fft(c_t,N)); % fft of carrier signal
subplot(4,1,2)
plot(f,abs(c_f));
grid;
title(" carrier signal(Frequency response)");
xlabel("f(Hz)");
ylabel("|C(f)|");

%% -----------------------------frequency domain(Magnitude response) representation of Modulated message signal----------------------
X_mod = fftshift(fft(x_mod,N)); %fft of modulated message signal;
subplot(4,1,3)
plot(f,abs(X_mod));
grid;
title(" Modulated signal(Frequency response)");
xlabel("f(Hz)");
ylabel("|Xmod(f)|");


%% ---------------------------frequency domain(Magnitude response) representation of Demodulated message signal-----------------------
X_demod = fftshift(fft(x_demod,N)); %fft of Demodulated message signal;
figure;
plot(f,abs(X_demod));
grid;
title(" Demodulated signal(Frequency response)");
xlabel("f(Hz)");
ylabel("|Xdemod(f)|");


