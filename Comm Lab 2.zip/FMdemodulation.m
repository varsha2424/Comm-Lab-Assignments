%% ----------------------------FM Demodulation------------------------------------------
%Here we are differntiatiating modulated signal and detecting signal considering upper
%side of envelop
function [x_demod] = FMdemodulation(x_mod)
dem = diff(x_mod); %differentiating of modulated signal               
dem = [0,dem];%appending zero as diff reduces length by 1 due to subraction of consecutive elements
[upper,lower] = envelope(dem);%envelop detection
m=  mean(upper.*4); %Scaling and shifting to get correct amplitudes
x_demod = upper.*4 - m;
x_demod = x_demod*2.5;

end
%x_mod is modulated message signal
%x_demod is demodulated signal using coherent demodulation