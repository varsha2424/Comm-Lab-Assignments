%% -------------------------------------clearing workspace and command prompt------------------------------------------------------
clear all;
close all;
clc;

%% -------------------------------------Simulation of QPSK in AWGN channel---------------------------------------------------------
constellations = (1/sqrt(2))*[1+1i,-1+1i,-1-1i,1-1i]; %normalised QPSK mappings without gray labeling
                                                      %(mapping 00 to 1+j ,01 to -1+j, 10 to -1-j and 11 to 1-j)
gray_constellations = (1/sqrt(2))*[1+1i,-1+1i,1-1i,-1-1i];%normalised QPSK mappings with gray labeling
                                                      %(mapping 00 to 1+j ,01 to -1+j, 10 to 1-j and 11 to -1-j)
snr_db = -10:0.3:10; %SNR values in DB
signal_len = 1000; %length of signal
snrs_len = length(snr_db); %length of SNR values
perr_estimate_non_gray = zeros(1,snrs_len); %bit error rates for taken SNR Values for without gray labeling
perr_estimate_gray = zeros(1,snrs_len); %bit error rates for taken SNR Values for with gray labeling

%----------------------------Binary Signal Genration------------------

random_no = randi([0 3],1,signal_len/2);%generating random numbers(0,1,2,3)with equal probability as to use ML detection
signal_bits = [];%Input signal
for iter = 1:signal_len/2
    if random_no(iter) == 0 
        signal_bits = [signal_bits;0,0];%generating 00 bits if number is 0
    elseif random_no(iter) == 1 
        signal_bits = [signal_bits;0,1];%generating 01 bits if number is 1
    elseif random_no(iter) == 2
        signal_bits = [signal_bits;1,0];%generating 10 bits if number is 2
    elseif random_no(iter) == 3 
        signal_bits = [signal_bits;1,1];%generating 11 bits if number is 3
    end
end


%---------------------------Modulating signal with gray scaling--------------------------

gray_modulated_signal = []; %we are mapping 00 to 1+j ,01 to -1+j, 10 to 1-j and 11 to -1-j
for iter_gray=1:length(signal_bits)
    if signal_bits(iter_gray,:) == [0 0]
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(1)];%mapping 00 to 1+j
    elseif signal_bits(iter_gray,:) == [0 1]
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(2)];%mapping 01 to -1+j
    elseif signal_bits(iter_gray,:) == [1 0]
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(3)];%mapping 10 to 1-j
    elseif signal_bits(iter_gray,:) == [1 1]
        gray_modulated_signal = [gray_modulated_signal;gray_constellations(4)]; %mapping 11 to -1-j
    end
end

%---------------------------Modulating signal without gray scaling--------------------------

modulated_signal = []; %we are mapping 00 to 1+j ,01 to -1+j, 10 to -1-j and 11 to 1-j
for iter=1:length(signal_bits)
    if signal_bits(iter,:) == [0 0]
        modulated_signal = [modulated_signal;constellations(1)];%mapping 00 to 1+j
    elseif signal_bits(iter,:) == [0 1]
        modulated_signal = [modulated_signal;constellations(2)];%mapping 01 to -1+j
    elseif signal_bits(iter,:) == [1 0]
        modulated_signal = [modulated_signal;constellations(3)];%mapping 10 to -1-j
    elseif signal_bits(iter,:) == [1 1]
        modulated_signal = [modulated_signal;constellations(4)];%mapping 11 to 1-j
    end
end

%-----------------------------Simulation-------------------------------
for snr=1:snrs_len %loop for snrs
    
    snrdb_now = snr_db(snr); %current SNR value in DB
    snr_now=10^(snrdb_now/10);%current SNR value in Linear Scale
    %sigma = sqrt(1/log2(M)*snb) here M = 4
    sigma=sqrt(1/(2*snr_now)); %sigma for corresponding SNR 
    error=zeros(1,signal_len); %error vector for current SNR for without gray labeling modulation
    gray_error=zeros(1,signal_len); %error vector for current SNR for with gray labeling modulation
    
    for i = 1:signal_len
        
         %In this loop we are adding AWGN noise to modulated signal for about 1000
         %times( length of signal) and we are considering average error rate(error probability) as
         %bit error rate for current snr
         
         %Adding normalised complex guassian noise to with gray modulated signal and
         %without gray modulated signal
         corrupted_signal = modulated_signal + [(sigma/sqrt(2))*(randn(1,length(modulated_signal))+1i*randn(1,length(modulated_signal)))]';
         gray_corrupted_signal = gray_modulated_signal + [(sigma/sqrt(2))*(randn(1,length(gray_modulated_signal))+1i*randn(1,length(gray_modulated_signal)))]';
         
         %Demodulating gray labeled corrupted signal and without gray
         %labeled signal
         %logic for demodulation - 
         %We are finding minimum distance from each symbol 
         demodulated_signal = [];%demodulated signal for without gray labeling modulation
         gray_demodulated_signal = [];%demodulated signal for with gray labeling modulation
         
         for cs = 1:length(corrupted_signal)
             dist = [];%distance for without gray labeled corrupted signal
             gray_dist = [];%distance for withgray labelled corrupted signal
             
             for j = 1:length(constellations)
                 %In this loop we find distance of corrupted signal(gray labeled and without gray labeled)
                 %with respective symbols
                 dist(j) = norm(corrupted_signal(cs)-constellations(j));%distance of corrupted signal from without gray labelled constellations
                 gray_dist(j) = norm(gray_corrupted_signal(cs)-gray_constellations(j));%distance of corrupted signal from with gray labelled constellations
             end
             
             [mini,index] = min(dist);%finding min index for without gray labeled corrupted signal
             [gray_mini,gray_index] = min(gray_dist);%finding min index for with gray labeled corrupted signal
             demodulated_signal = [demodulated_signal;constellations(index)];%appending min distance symbol for demodulated signal
             gray_demodulated_signal = [gray_demodulated_signal;gray_constellations(gray_index)];%appending min distance symbol for demodulated signal
         end
         
         %finding bit error for demodulated signal (gray labeled and without gray labeled)
         error(i) =ber(demodulated_signal,modulated_signal);
         gray_error(i) =ber(gray_demodulated_signal,gray_modulated_signal);
    
    end
    perr_estimate_non_gray(snr) = mean(error);%appending average error as bit error rate for current SNR(for without gray labeled)
    perr_estimate_gray(snr) = mean(gray_error);%appending average error as bit error rate for current SNR(for gray labeled)
    
end

%% -----------------------------Theoretical values using Q-function(Intelligent Union Bound)----------------------------------------
theory_snr=-10:.5:10; %theoretical SNR values in DB
theory_snr_lin=10.^(theory_snr./10);%theoretical SNR values in Linear scale
ber=1/2*erfc(sqrt(theory_snr_lin));%bit error rates using complementary error function

%% -----------------------------Comparing theoretical vs simulated Bit error rates for without gray labeling------------------------- 
figure;
semilogy(theory_snr,1.5*ber,'b-','linewidth',2) %semilog plot for theoretical bit error rates
hold on
semilogy(snr_db,perr_estimate_non_gray,'r-o') %semilog plot for simulated bit error rates
hold off
title('QPSK over AWGN Simulation without gray labeling');
xlabel('SNR in dB');ylabel('BER');
legend('BER(Theoretical)','BER(Simulated)')
ber = 1.8*ber;
grid;


%% -----------------------------Comparing theoretical vs simulated Bit error rates for gray labeling---------------------------------- 
figure;
semilogy(theory_snr,ber,'b-','linewidth',2) %semilog plot for theoretical bit error rates
hold on
semilogy(snr_db,perr_estimate_gray,'r-o') %semilog plot for simulated bit error rates
hold off
title('QPSK over AWGN Simulation with gray labeling');
xlabel('SNR in dB');ylabel('BER');
legend('BER(Theoretical)','BER(Simulated)')
grid;